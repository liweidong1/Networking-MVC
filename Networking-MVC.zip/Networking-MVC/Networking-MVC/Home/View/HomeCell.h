//
//  HomeCell.h
//  Networking-MVC
//
//  Created by liweidong on 17/11/7.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DLHomePageMenuModel.h"
@interface HomeCell : UITableViewCell
@property(nonatomic,strong)UIImageView *iv;
@property(nonatomic,strong)UILabel *nameLab;

@property (nonatomic, strong) DLHomeMenuItem *homeMenuItem;


- (void)configureCell:(DLHomeMenuItem *)data;
@end
