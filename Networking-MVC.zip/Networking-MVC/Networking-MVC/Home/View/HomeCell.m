//
//  HomeCell.m
//  Networking-MVC
//
//  Created by liweidong on 17/11/7.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "HomeCell.h"

@implementation HomeCell

- (UIImageView *)iv {
    if(_iv == nil) {
        _iv = [[UIImageView alloc] init];
        [self.contentView addSubview:_iv];
        [_iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(@0);
            make.height.equalTo(@100);
        }];
    }
    return _iv;
}

- (UILabel *)nameLab {
    if(_nameLab == nil) {
        _nameLab = [[UILabel alloc] init];
        [self.contentView addSubview:_nameLab];
        [_nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(@0);
            make.top.equalTo(self.iv.mas_bottom).equalTo(@0);
            make.height.equalTo(@30);
        }];
    }
    return _nameLab;
}


#pragma mark - configure

- (void)configureCell:(DLHomeMenuItem *)data {
    [self.iv sd_setImageWithURL:[NSURL URLWithString:data.pic_icon] placeholderImage:[UIImage imageNamed:@"头像默认占位图"]];
    self.nameLab.text = data.name;
}

@end
