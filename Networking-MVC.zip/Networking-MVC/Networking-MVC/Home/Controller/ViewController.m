//
//  ViewController.m
//  Networking-MVC
//
//  Created by liweidong on 17/11/7.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ViewController.h"
#import "HomeCell.h"
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSArray *apps;
@end
static NSString * const reuseIdentifier = @"Cell";
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTableView];
    [self fetchData];
}
-(void)fetchData
{
    NSDictionary *param = @{@"uid" : @"1392",
                            @"sign_token" : @"2a8407a2cddff45fff10815a34c609d7",
                            };
    [DLHomeViewTask getHomeIndexMod:param completion:^(id result, NSError *error) {
        NSLog(@"MVC-json数据：%@",result);
        DLHomePageMenuModel *homePageMenuModel = [DLHomePageMenuModel mj_objectWithKeyValues:result];
        self.apps = homePageMenuModel.columnList;
        [self.tableView reloadData];
        
        if (self.didCompleteLoad) {
            self.didCompleteLoad(homePageMenuModel);
        }
    }];
}


-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.bounds];
    self.tableView.rowHeight = ([UIScreen mainScreen].bounds.size.width * 618/480);
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:[HomeCell class] forCellReuseIdentifier:reuseIdentifier];
    
}

#pragma UITableViewDelegate  Datasource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _apps.count;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HomeCell* cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    DLHomeMenuItem *menuItem = [self.apps objectAtIndex:indexPath.section];
    cell.homeMenuItem = menuItem;
    [cell configureCell:menuItem];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 130;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5;
}

@end
