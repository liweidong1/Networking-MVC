//
//  ViewController.h
//  Networking-MVC
//
//  Created by liweidong on 17/11/7.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DLHomePageMenuModel.h"
@interface ViewController : UIViewController

/**
 *  加载完成
 */
@property (nonatomic, copy) void (^didCompleteLoad)(DLHomePageMenuModel *homePageMenuModel);
@end

