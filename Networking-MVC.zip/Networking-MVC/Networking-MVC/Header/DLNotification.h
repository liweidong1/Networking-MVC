//
//  DLNotification.h
//  Dalv
//
//  Created by Nie on 2017/6/18.
//  Copyright © 2017年 Michael 柏. All rights reserved.
//

#ifndef DLNotification_h
#define DLNotification_h

//退出登录
extern NSString *const kUserlogoutNotification;

//登录成功
extern NSString *const kUserlogInNotification;

//提现成功发送通知
extern NSString *const kFianceNotification;


//
extern NSString *const KCustomerloginNoti;
//登录成功,显示Alert通知
extern NSString *const kFirstUserlogoutAlertNotification;

//修改头像
extern NSString *const kAlertUserHeaderImg;
//未审核提交认证信息
extern NSString *const kSubmitCertifyInfo;

//登录判断是否激活显示弹框
extern NSString *const kUserlogInChectNotification;
#endif /* DLNotification_h */

