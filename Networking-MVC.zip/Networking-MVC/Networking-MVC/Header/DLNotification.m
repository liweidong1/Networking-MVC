//
//  DLNotification.m
//  Dalv
//
//  Created by Nie on 2017/6/18.
//  Copyright © 2017年 Michael 柏. All rights reserved.
//

#import "DLNotification.h"

NSString *const kUserlogoutNotification = @"userlogoutNotification";

NSString *const kUserlogInNotification = @"kUserlogInNotification";

NSString *const KCustomerloginNoti = @"KCustomerloginNoti";

NSString *const kFianceNotification = @"kFianceNotification";

NSString *const kFirstUserlogoutAlertNotification = @"kFirstUserlogoutAlertNotification";

NSString *const kAlertUserHeaderImg = @"kALERTUSERHEADERIMG";

NSString *const kSubmitCertifyInfo = @"kSubmitCertifyInfo";

NSString *const kUserlogInChectNotification = @"kUserlogInCheckNotification";

