//
//  InterfaceConfig.h
//  Dalv
//
//  Created by Nie on 2017/5/18.
//  Copyright © 2017年 Michael 柏. All rights reserved.
//

#ifndef InterfaceConfig_h
#define InterfaceConfig_h

// DEBUG 运行为测试环境，RELEASE运行为正式环境
//#ifdef __OPTIMIZE__
//#ifndef __OPTIMIZE__
// 注释DL_DEVELOP_SERVICE宏为测试环境，打开为开发环境
//       #define DL_DEVELOP_SERVICE
//        #ifndef DL_DEVELOP_SERVICE
          // 大旅接口测试服务器
//           #define DL_HOST @"http://demoapi.dalvu.com/"
//        #else
         // 大旅接口开发服务器
      //     #define DL_HOST @"http://dalvuapi.dalvu.com/"
//       #endif

/// 测试接口服务器
#define DL_HOST @"http://demoapi.dalvu.com/"

///线上服务器
//#define DL_HOST  @"http://dalvuapi.dalvu.com/"

// 1.测试默认首页模块地址
//#define DL_HomeIndexMod DL_HOST@"index.php/Api/index/indexMod"    //1.0老版本
//#define DL_HomeIndexMod DL_HOST@"index.php/Api/index/indexModNowTwo"//1.2新版本
#define DL_HomeIndexMod DL_HOST@"index.php/Api/index/indexModNowThree"//1.3新版本
// 2.测试默认首页线路列表地址
#define DL_HomeIndexLineList DL_HOST@"index.php/Api/index/indexLineList"

// 3.测试默认详情页地址：①
//#define DL_LineDetials DL_HOST@"index.php/Api/index/details"//老版本1.0
#define DL_LineDetials DL_HOST@"index.php/Api/index/detailsNowThree"//新版本1.3
// 4.测试详情页地址-行程安排：②
#define DL_LineDetialsScheduling DL_HOST@"index.php/Api/index/detailsScheduling"

// 5测试详情页地址-产品亮点：③
#define DL_LineDetialsEdge DL_HOST@"index.php/Api/index/detailsEdge"

// 6.测试详情页地址-费用说明：④
#define DL_LineDetialsCostExplain DL_HOST@"index.php/Api/index/detailsCostExplain"

// 7.测试详情页地址-注意事项：⑤
#define DL_LineDetialsNotice DL_HOST@"index.php/Api/index/detailsNotice"

// 8.测试注册时发送短信接口地址
#define DL_LoginAgencyVerificationCode DL_HOST@"index.php/Api/login/agencyVerificationCode"

// 9.测试顾问注册接口地址
#define DL_LoginAgencyRegister DL_HOST@"index.php/Api/login/agencyRegister"

// 10.测试登陆接口地址
//#define DL_Login DL_HOST@"index.php/Api/login/agencyIndex" //老版本1.0
//#define DL_Login DL_HOST@"index.php/Api/login/agencyIndexNowTwo" //版本1.2接口
//#define DL_Login DL_HOST@"index.php/Api/login/agencyIndexNowThree" //版本1.3接口 （新增账户激活字段audit_status）
#define DL_Login DL_HOST@"index.php/Api/login/agencyIndexNowFour" //版本1.4接口 （（接口新增参数，device_type (设备类型)，device_tokens(设备tokens)）
// 11.测试顾问首页模块接口地址
//#define DL_HomeAgencyIndexMod DL_HOST@"index.php/Api/index/agencyIndexMod"//老版本1.0
//#define DL_HomeAgencyIndexMod DL_HOST@"index.php/Api/index/agencyIndexModNowTwo"//版本1.2接口
//#define DL_HomeAgencyIndexMod DL_HOST@"index.php/Api/index/agencyIndexModNowThree"//版本1.3接口
#define DL_HomeAgencyIndexMod DL_HOST@"index.php/Api/index/agencyIndexModNowFour"//版本1.4接口 新增接口wifi
// 12.测试顾问首页线路列表接口地址
#define DL_HomeAgencyLinelist DL_HOST@"index.php/Api/index/agencyIndexLinelist"

// 13.   (1)测试顾问（登陆状态）线路详情页接口地址（已审核）
//#define DL_AgencyDetails DL_HOST@"index.php/Api/agency/details"
//#define DL_AgencyDetails DL_HOST@"index.php/Api/agency/detailsNowThree"
#define DL_AgencyDetails DL_HOST@"index.php/Api/agency/detailsNowFour"//新版本1.4接口 (对未审核通过的顾问返回“该顾问账号未审核通过”)
//       (2)测试顾问（登陆状态）线路详情页接口地址（未审核）
#define DL_AgencyDetailsNocheck DL_HOST@"index.php/Api/agency/notAuditedDetails"// 测试顾问（未审核状态）线路详情页接口地址


// 14.测试顾问线路修改标题接口地址
#define DL_AgencyPersonalChangeTitle DL_HOST@"index.php/Api/agency/changeTitle"

// 15.测试顾问线路修改价格页面接口地址
#define DL_AgencyChangePrice DL_HOST@"index.php/Api/agency/changePrice"

// 16.测试顾问线路修改价格处理接口地址
#define DL_AgencyChangePriceHandle DL_HOST@"index.php/Api/agency/changePriceHandle"

// 17.测试顾问推荐线路处理接口地址
#define DL_AgencyRecommend DL_HOST@"index.php/Api/agency/recommend"

// 18.测试顾问提交订单页面接口地址
#define DL_AgencyOrderInfo DL_HOST@"index.php/Api/agency/orderInfo"

// 19.测试顾问提交订单处理接口地址
#define DL_AgencyOrderInfoHandle DL_HOST@"index.php/Api/agency/orderInfoHandle"

// 20.测试顾问个人中心接口地址
//#define DL_AgencyPersonal DL_HOST@"index.php/Api/agencyPersonal/index"//1.0老版本
//#define DL_AgencyPersonal DL_HOST@"index.php/Api/agencyPersonal/indexNowTwo"//1.2新版本
#define DL_AgencyPersonal DL_HOST@"index.php/Api/agencyPersonal/indexNowThree"//1.3新版本(新增签到)
// 21.测试修改密码页面接口
#define DL_AgencyEditPass DL_HOST@"index.php/Api/agencyPersonal/agencyEditPass"

// 22.测试顾问修改密码处理接口
#define DL_AgencyEditPassHandle DL_HOST@"index.php/Api/agencyPersonal/agencyEditPassHandle"

// 23.测试顾问页面设置页面接口
#define DL_AgencyPageSetUp DL_HOST@"index.php/Api/agencyPersonal/agencyPageSetUp"

// 24.测试顾问模块排序页面接口
#define DL_AgencyColumnSort DL_HOST@"index.php/Api/agencyPersonal/agencyColumnSort"

// 25.测试顾问模块排序处理接口
#define DL_AgencyColumnSortHandle DL_HOST@"index.php/Api/agencyPersonal/agencyColumnSortHandle"

// 26.测试顾问线路订单列表接口
#define DL_AgencyLineOrder DL_HOST@"index.php/api/Agencypersonal/agencyLineOrder.html"

// 27.测试顾问签证订单列表接口
#define DL_AgencyOrderVisaOrder DL_HOST@"index.php/Api/agencyOrder/visaOrder"

// 28.测试顾问Wifi订单列表接口
#define DL_AgencyOrderWifiOrder DL_HOST@"index.php/Api/agencyOrder/wifiOrder"

// 29.测试顾问其他订单列表接口
#define DL_AgencyOrderOtherOrder DL_HOST@"index.php/Api/agencyOrder/otherOrder"

// 30.测试顾问财务管理列表接口
#define DL_AgencyFinance DL_HOST@"index.php/Api/agencyFinance/index"

// 31.测试顾问财务管理->交易记录接口
#define DL_AgencyFinanceAccountTransaction DL_HOST@"index.php/Api/agencyFinance/accountTransaction"

// 32.测试顾问财务管理->充值申请页面接口
#define DL_AgencyFinanceApplyTopup DL_HOST@"index.php/Api/agencyFinance/applyTopup"

// 33.测试顾问财务管理->充值申请处理接口（线下充值）
#define DL_AgencyFinanceApplyTopupHandle DL_HOST@"index.php/Api/agencyFinance/applyTopupHandle"

// 34.测试顾问财务管理->充值申请记录接口
#define DL_AgencyFinanceTopupList DL_HOST@"index.php/Api/agencyFinance/topupList"

// 35.测试顾问财务管理->提现申请页面接口
#define DL_AgencyFinanceApplyWithdraw DL_HOST@"index.php/Api/agencyFinance/applyWithdraw"

// 36.测试顾问财务管理->提现申请处理接口
#define DL_AgencyFinanceApplyWithdrawHandle DL_HOST@"index.php/Api/agencyFinance/applyWithdrawHandle"

// 37.测试顾问财务管理->提现记录列表接口
#define DL_AgencyFinanceWithdrawList DL_HOST@"index.php/Api/agencyFinance/withdrawList"

// 38.测试顾问财务管理->发票申请页面接口
#define DL_AgencyFinanceApplyInvoicet DL_HOST@"index.php/Api/agencyFinance/applyInvoice"

// 39.测试顾问财务管理->发票申请处理接口
#define DL_AgencyFinanceApplyInvoicetHandle DL_HOST@"index.php/Api/agencyFinance/applyInvoiceHandle"

// 40.测试顾问财务管理->发票记录列表接口
#define DL_AgencyFinanceInvoicetList DL_HOST@"index.php/Api/agencyFinance/invoiceList"

// 41.测试顾问财务管理->合同申请页面接口
#define DL_AgencyFinanceApplyContract DL_HOST@"index.php/Api/agencyFinance/applyContract"

// 42.测试顾问财务管理->合同申请处理接口
#define DL_AgencyFinanceApplyContractHandle DL_HOST@"index.php/Api/agencyFinance/applyContractHandle"

// 43.测试顾问财务管理->合同申请记录列表接口
#define DL_AgencyFinanceContractList DL_HOST@"index.php/Api/agencyFinance/contractList"

// 44.测试顾问个人中心->我的推荐列表接口
#define DL_AgencyFinanceMyRecommend DL_HOST@"index.php/Api/agencyFinance/myRecommend"

// 45.测试顾问个人中心->我的推荐线路删除接口
#define DL_AgencyFinanceMyRecommendDel DL_HOST@"index.php/Api/agencyFinance/myRecommendDel"

// 46.测试顾问个人中心->我的机票列表接口
#define DL_AgencyFlightMyPlaneTicket DL_HOST@"index.php/Api/agencyFlight/myPlaneTicket"

// 47.测试顾问个人中心->我的机票详情接口
#define DL_AgencyFlightPlaneTicketDetail DL_HOST@"index.php/Api/agencyFlight/planeTicketDetail"

// 48.测试顾问个人中心->我的直客页面接口
#define DL_AgencyFlightFlightProfit DL_HOST@"index.php/Api/agencyFlight/flightProfit"

// 49.测试顾问个人中心->我的直客机票订单列表接口
#define DL_AgencyFlightVisitorPlaneTicket DL_HOST@"index.php/Api/agencyFlight/visitorPlaneTicket"

// 50.测试顾问个人中心->我的直客机票订单详情页接口
#define DL_AgencyFlightPlaneProfitDetail DL_HOST@"index.php/Api/agencyFlight/planeProfitDetail"

// 51.(1)测试顾问个人中心->供应商查询页面接口
#define DL_AgencyPersonalProviderQuery DL_HOST@"index.php/Api/agencyPersonal/providerQuery"
//    (2)测试顾问个人中心->供应商查询页面搜索按钮接口
#define DL_AgencyPersonalProviderQuerySearch DL_HOST@"index.php/Api/agencyPersonal/providerQuerySearchHandle"

//  获取验证码
#define DL_consultGetCode DL_HOST@"index.php/Api/login/agencyVerificationCode"
//  注册
#define DL_ConsultRegister DL_HOST@"index.php/Api/login/agencyRegister"

//  供应商查询
#define DL_providerQuery DL_HOST@"index.php/Api/agencyPersonal/providerQuery"

//  顾客注册的接口
#define DL_CustomerRegister DL_HOST@"index.php/TouristApi/TouristLogin/touristRegister"

// 52.顾问订单列表界面接口
#define DL_AgencyLineOrderList DL_HOST@"index.php/api/AgencyOrder/lineOrder"


// 53.顾问订单详情界面接口
#define DL_AgencyLineOrderListDetails DL_HOST@"index.php/Api/agencyOrder/lineDetails"

// 54.我的直客列表接口    修改后--->默认可加载
#define DL_AgencyMyCustomerList DL_HOST@"index.php/Api/agencyFlight/visitorListScreen"



// 55.测试顾问线路订单详情页-付全款，付预付，付尾款页面接口
#define DL_AgencyLineOrderDetailConfirmPayment DL_HOST@"index.php/Api/agencyPersonal/agencyShowAllPayed"

// 56.测试首页线路输入搜素接口地址
//#define DL_LineSearch DL_HOST@"index.php/Api/index/indexLineSearch"//老版本1.0
#define DL_LineSearch DL_HOST@"index.php/Api/index/indexLineSearchNowTwo"  //新版本1.2

// 57.测试首页出发城市搜素接口地址
#define DL_DepartureSearch DL_HOST@"index.php/Api/index/indexDepartureSearch"

// 58.测试（首页模块）栏目接口地址（如出境游，国内游等）
#define DL_HomeOutbound DL_HOST@"index.php/Api/Outbound/index"

// 59.测试顾问修改头像处理接口
#define DL_AgencyEditHendImgHandle DL_HOST@"index.php/Api/agencyPersonal/agencyEditHendImgHandle"

// 60.测试详情页地址-目的地图册
#define DL_AgencyMorePics DL_HOST@"index.php/Api/agency/morePics"

//61.测试顾问线路订单详情页-付全款处理接口
#define DL_AgencyAllpayed DL_HOST@"index.php/Api/agencyPersonal/agencyAllPayed"

//62.测试顾问线路订单详情页-付预付款处理接口
#define DL_AgencyPrePayed DL_HOST@"index.php/Api/agencyPersonal/agencyPrePayed"

//63.测试顾问线路订单详情页-付尾款处理接口
#define DL_AgencyPreForum DL_HOST@"index.php/Api/agencyPersonal/agencyPreForum"

//64.测试顾问个人资料设置页面接口
#define DL_AgencyPersonalPageSetUp DL_HOST@"index.php/Api/agencyPersonal/agencyPageSetUp"

//65.测试顾问个人资料设置页面接口
#define DL_AgencyPersonalSetUpHandle DL_HOST@"index.php/Api/agencyPersonal/agencyPageSetUpHandle"

//66.测试普通用户绑定前获取验证码地址接口
#define DL_TouristVerificationCode DL_HOST@"index.php/TouristApi/TouristLogin/touristVerificationCode"

//67.测试普通用户绑定并直接登陆地址接口
//#define DL_TouristLoginRegister DL_HOST@"index.php/TouristApi/TouristLogin/touristRegister"
#define DL_TouristLoginRegister DL_HOST@"index.php/TouristApi/TouristLogin/touristRegisterNowTwo"
//68.测试普通用户-绑定顾问后首页模块接口
//#define DL_TouristAgencyIndexMod  DL_HOST@"index.php/TouristApi/TouristIndex/agencyIndexMod"
//#define DL_TouristAgencyIndexMod  DL_HOST@"index.php/TouristApi/TouristIndex/agencyIndexModNowTwo"
#define DL_TouristAgencyIndexMod  DL_HOST@"index.php/TouristApi/TouristIndex/agencyIndexModNowThree"
//69 测试普通用户个人中心地址接口
#define DL_TouristPersonalIndex  DL_HOST@"index.php/TouristApi/TouristPersonal/index"

// 70 测试普通用户个人中心-我的顾问（已经绑定）列表地址接口：
#define DL_TouristPersonalMyAgency  DL_HOST@"index.php/TouristApi/TouristPersonal/myAgency"

// 71 测试普通用户个人中心-我的顾问（已经绑定）列表地址接口：
//#define DL_TouristPersonalMyAgencyUnBinding  DL_HOST@"index.php/TouristApi/TouristPersonal/agencyList"//老接口1.0
#define DL_TouristPersonalMyAgencyUnBinding  DL_HOST@"index.php/TouristApi/TouristPersonal/agencyListNowTow"//新接口1.2
// 72 测试（首页模块）栏目二级列表接口地址（如出境游，国内游等）
#define DL_OutboundLists  DL_HOST@"index.php/Api/Outbound/lists"

// 73 测试普通用户修改个人资料页面地址接口
//#define DL_TouristPersonalPageData  DL_HOST@"index.php/TouristApi/TouristPersonal/dataPage"//1.0老接口
#define DL_TouristPersonalPageData  DL_HOST@"index.php/TouristApi/TouristPersonal/dataPageNowThree"//2.0新接口

// 74 测试普通用户修改个人资料处理地址接口
//#define DL_TouristPersonalPageDataHandle  DL_HOST@"index.php/TouristApi/TouristPersonal/dataPageHandle"//老版本1.0
#define DL_TouristPersonalPageDataHandle  DL_HOST@"index.php/TouristApi/TouristPersonal/dataPageHandleNowThree"//新版本1.2
///75 测试普通用户个人中心-我的顾问（已绑定）解绑接口
#define DL_TouristPersonalUnbundlingAgency  DL_HOST@"index.php/TouristApi/TouristPersonal/unbundlingAgency"

//// 76 测试普通用户-绑定顾问后首页模块接口
//#define DL_TouristAgencyIndexMod  DL_HOST@"index.php/TouristApi/TouristIndex/agencyIndexMod"

// 77 测试普通用户-绑定顾问后首页线路列表接口
#define DL_TouristAgencyIndexLinelist  DL_HOST@"index.php/TouristApi/TouristIndex/agencyIndexLinelist"

// 78 测试普通用户-绑定顾问后线路详情接口
//#define DL_TouristIndexDetails  DL_HOST@"index.php/Api/index/details"//老版本1.0
//#define DL_TouristIndexDetails  DL_HOST@"index.php/Api/index/detailsNowTwo"//新版本1.2
#define DL_TouristIndexDetails  DL_HOST@"index.php/Api/index/detailsNowThree"

///76 测试普通用户个人中心-我的顾问（未绑定）绑定接口
#define DL_TouristPersonalbundingAgency  DL_HOST@"index.php/TouristApi/TouristPersonal/bindingAgencyNowTwo"

///79 测试普通用户个人中心-我的顾问（未绑定）详情页地址接口
#define DL_TouristPersonalAgencyDetails  DL_HOST@"index.php/TouristApi/TouristPersonal/agencyDetails"

///80 测试财务中心微信App充值接口
#define DL_WxpayAppDopay  DL_HOST@"index.php/Api/wxpayApp/dopay"

///81 测试首页机票查询处理返回机票列表接口
#define DL_FlightQueryList  DL_HOST@"index.php/Api/agencyFlight/flightQueryList"

///82 测试财务中心支付宝App充值接口
#define DL_AlipayAppDopay  DL_HOST@"index.php/Api/alipayApp/aliDopay"

///83 测试首页机票添加乘机人-新增乘机人接口
#define DL_FlightAddPassenger  DL_HOST@"index.php/Api/agencyFlight/addFrequentPassenger"



//84，	测试顾问个人中心->顾问询价处理接口
#define DL_RoutePriceQuery  DL_HOST@"index.php/Api/agencyPersonal/agencyInquiryHandle"
//85   测试顾问首页单团提交订单处理接口
#define DL_SubmitSingleGroupOrder DL_HOST@"index.php/Api/SingleGroup/agnecySingleOrderHandle"
//86   测试顾问首页单团订单页面返回供应商列表接口
#define DL_SupplierList DL_HOST@"index.php/Api/SingleGroup/providerList"
//86  测试顾问订单中心-单团订单列表接口
#define DL_SingleGroupList DL_HOST@"index.php/Api/AgencyOrder/singleGroupOrder"
//87  测试顾问订单中心-单团订单详情页接口
#define DL_SingleGroupDetail DL_HOST@"index.php/Api/AgencyOrder/singleGroupDetails"
//88  测试顾问单团订单详情-付预付款处理接口
#define DL_SingleGroupPrePay DL_HOST@"index.php/Api/AgencyOrder/agencySingleGroupPrePayed"
//89  测试顾问单团订单详情-付全款处理接口
#define DL_SingleGroupTotalPay DL_HOST@"index.php/Api/AgencyOrder/agencySingleGroupAllPayed"
//90  测试顾问单团订单详情-付尾款处理接口
#define DL_SingleGroupEndPay DL_HOST@"index.php/Api/AgencyOrder/agencySingleGroupPreForum"
//90  测试普通用户个人中心-我的顾问（未绑定）条件筛选接口
//#define DL_TouristPersonalMyAgencyUnBindingConditionFilter  DL_HOST@"index.php/TouristApi/TouristPersonal/agencyListScreen"
#define DL_TouristPersonalMyAgencyUnBindingConditionFilter  DL_HOST@"index.php/TouristApi/TouristPersonal/agencyListScreenNowTwo"//1.2新接口
//91  测试顾问个人中心->我的直客详情页接
#define DL_AgencyMyCustomerDetail  DL_HOST@"index.php/Api/agencyFlight/visitorDetails"
//92 测试顾问个人中心-认证信息页面接口（身份证正反面，银行信息）
#define DL_AgencyMyPersonCertifyInfo  DL_HOST@"index.php/Api/agencyPersonal/agencyAuthPageSetUp"
//93 (1)测试顾问个人中心-认证资料设置处理（银行信息）
#define DL_AgencyMyPersonCertifySubmit  DL_HOST@"index.php/Api/agencyPersonal/agencyBankInfoHandle"
//   (2)测试顾问个人中心-认证资料设置处理（身份证正面）
#define DL_AgencyMyPersonCertifyIDFront  DL_HOST@"index.php/Api/agencyPersonal/agencyJustImgHandle"
//   (3)测试顾问个人中心-认证资料设置处理（身份证反面面）
#define DL_AgencyMyPersonCertifyIDBack  DL_HOST@"index.php/Api/agencyPersonal/agencyBackImgHandle"
//94  测试顾问未审核状态下显示运营商信息
#define DL_AgencyMySupplierInfo  DL_HOST@"index.php/Api/index/operatorInfo"
//95 测试顾问个人中心-认证中时，取消认证接口（身份证正反面，银行信息）
#define DL_AgencyMyPersonCertifyingCancel  DL_HOST@"index.php/Api/agencyPersonal/agencyCancelAuth"
//96.测试游客修改头像处理接口
#define DL_TouristEditHendImgHandle DL_HOST@"index.php/TouristApi/TouristPersonal/touristEditHendImgHandle"
// 97. 测试顾问订单中心—超级wifi详情页接口
#define DL_AgencyOrderWifiOrderDetail DL_HOST@"index.php/Api/agencyOrder/wifiOrderDetails"
// 98. 	测试顾问个人中心-签到处理接口
#define DL_AgencySignInHandle DL_HOST@"index.php/Api/agencyPersonal/agencySign"
// 99. 	测试顾问个人中心-签到成功后显示积分列表接口
#define DL_AgencySignInList DL_HOST@"index.php/Api/agencyPersonal/agencyIntegralList"
// 100. 测试顾问超级WIFI产品订单支付接口
#define DL_AgencyOrderWifiOrderPayHandle DL_HOST@"index.php/Api/agencyAuxiliaryProducts/orderWifiPay"
// 101. 测试顾问超级WIFI国家分类列表接口
#define DL_AgencyWifiCountryList DL_HOST@"index.php/Api/agencyAuxiliaryProducts/wifiCountryList"
// 102. 测试顾问超级WIFI国家下级的WIFI产品列表接口
#define DL_AgencyCountryWifiList DL_HOST@"index.php/Api/agencyAuxiliaryProducts/countryWifiList"
// 103. 测试顾问超级WIFI产品详情页接口
#define DL_AgencyCountryWifiDetail DL_HOST@"index.php/Api/agencyAuxiliaryProducts/agencyWifiDetails"
// 104. 测试顾问超级WIFI产品订单提交信息页面接口
#define DL_AgencyCountryWifiOrderPage DL_HOST@"index.php/Api/agencyAuxiliaryProducts/wifiOrderPage"
// 105. 测试顾问超级WIFI产品订单提交接
#define DL_AgencyCountryWifiOrderHandle DL_HOST@"index.php/Api/agencyAuxiliaryProducts/orderWifiOrder"
// 106. 测试游客超级WIFI产品详情页接口
#define DL_TouristCountryWifiDetail DL_HOST@"index.php/Api/agencyAuxiliaryProducts/touristWifiDetails"
// 107. 测试首页机票创建订单处理接口
#define DL_AgencyFlightOrderCreat DL_HOST@"index.php/Api/agencyFlight/flightOrderCreate"
//108.  测试首页机票添加乘机人显示顾问可选的乘机人列表接口
#define DL_AgencyFlightAddPassengersInfoList DL_HOST@"index.php/Api/agencyFlight/addPassengers"
//109.  测试首页机票—删除乘机人信息处理接口
#define DL_AgencyFlightEditDeleteHandle DL_HOST@"index.php/Api/agencyFlight/delPassengerData"
//110.  测试首页机票订单确认支付处理接口
#define DL_AgencyFlightOrderPay  DL_HOST@"index.php/Api/agencyFlight/orderPay"

#endif /* InterfaceConfig_h */
